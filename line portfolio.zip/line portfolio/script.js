var abc=document.getElementById("preloader")
window.addEventListener("load", myfunction);
function myfunction(){abc.style.display="none";}